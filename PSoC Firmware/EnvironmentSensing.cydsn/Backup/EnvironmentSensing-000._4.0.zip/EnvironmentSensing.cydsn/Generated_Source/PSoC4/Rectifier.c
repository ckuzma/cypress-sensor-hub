/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "Rectifier.h"
#include "Rectifier_UABH_B.h"

void Rectifier_Start(void)
{
    Rectifier_UABH_B_Start();
}
/* [] END OF FILE */
